let currentColor = 'black';
let shapePoints = [];
let tracedPoints = [];
let completed = false;
let shapePerimeter = 0;

function setup() {
  createCanvas(400, 400);
  shapePoints = [
    createVector(150, 20),
    createVector(215, 220),
    createVector(50, 100),
    createVector(250, 100),
    createVector(85, 220)
  ];
  shapePerimeter = calculatePerimeter(shapePoints);
  const colors = ['red', 'green', 'blue', 'yellow', 'purple'];
  let xPos = 300;
  let yPos = 50;
  for (let color of colors) {
    let colorDiv = createDiv('');
    colorDiv.style('background-color', color);
    colorDiv.style('width', '50px');
    colorDiv.style('height', '30px');
    colorDiv.style('margin', '5px');
    colorDiv.mousePressed(() => chooseColor(color));
    colorDiv.position(xPos, yPos);
    yPos += 35;
  }
}

function draw() {
  background(220);
  stroke(0);
  fill(255);
  beginShape();
  for (let pt of shapePoints) {
    vertex(pt.x, pt.y);
  }
  endShape(CLOSE);
  if (tracedPoints.length > 0) {
    stroke(currentColor);
    strokeWeight(2);
    beginShape();
    for (let pt of tracedPoints) {
      vertex(pt.x, pt.y);
    }
    endShape();
  }
  if (completed) {
    fill(0);
    textSize(32);
    textAlign(CENTER);
    text("Yay!", width / 2, height / 2);
  }
  fill(0);
  textSize(14);
  textAlign(CENTER, CENTER);
  let instructions = "Trace the star with your mouse.\nChoose a color from the right before starting.";
  text(instructions, width / 2, height - 45); // Center text at the bottom of the canvas
}

function mousePressed() {
  if (!completed && isInsideShape(mouseX, mouseY)) {
    tracedPoints = [];
    addPoint(mouseX, mouseY);
  }
}

function mouseDragged() {
  if (!completed && isInsideShape(mouseX, mouseY)) {
    addPoint(mouseX, mouseY);
  }
}

function mouseReleased() {
  if (tracedPoints.length > 0) {
    let tracedLength = calculateTracedLength(tracedPoints);
    if (tracedLength >= 0.7 * shapePerimeter) {
      completed = true;
    }
  }
}

function chooseColor(color) {
  currentColor = color;
}

function addPoint(x, y) {
  tracedPoints.push(createVector(x, y));
}

function isInsideShape(x, y) {
  let inside = false;
  beginShape();
  for (let pt of shapePoints) {
    vertex(pt.x, pt.y);
  }
  endShape(CLOSE);
  for (let i = 0; i < shapePoints.length; i++) {
    let j = (i + 1) % shapePoints.length;
    if ((shapePoints[i].y > y) != (shapePoints[j].y > y) &&
        (x < (shapePoints[j].x - shapePoints[i].x) * (y - shapePoints[i].y) / (shapePoints[j].y - shapePoints[i].y) + shapePoints[i].x)) {
      inside = !inside;
    }
  }
  return inside;
}

function calculatePerimeter(points) {
  let perimeter = 0;
  for (let i = 0; i < points.length; i++) {
    let nextIndex = (i + 1) % points.length;
    perimeter += dist(points[i].x, points[i].y, points[nextIndex].x, points[nextIndex].y);
  }
  return perimeter;
}

function calculateTracedLength(points) {
  let length = 0;
  for (let i = 0; i < points.length - 1; i++) {
    length += dist(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
  }
  return length;
}

let shapes = [];
let holes = [];

function setup() {
  createCanvas(400, 400);
  
  // Create shapes
  shapes.push(new Shape(100, 300, 'circle'));
  shapes.push(new Shape(200, 300, 'square'));
  shapes.push(new Shape(300, 300, 'triangle'));
  
  // Create holes
  holes.push(new Hole(100, 100, 'circle'));
  holes.push(new Hole(200, 100, 'square'));
  holes.push(new Hole(300, 100, 'triangle'));
}

function draw() {
  background(220);
  
  // Display instructions
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("Drag the shapes to their matching slots!", width / 2, 30);
  
  // Draw holes
  for (let hole of holes) {
    hole.display();
  }
  
  // Draw shapes
  for (let shape of shapes) {
    shape.display();
  }
}

function mousePressed() {
  for (let shape of shapes) {
    if (shape.isMouseInside()) {
      shape.isDragging = true;
      shape.offsetX = mouseX - shape.x;
      shape.offsetY = mouseY - shape.y;
    }
  }
}

function mouseDragged() {
  for (let shape of shapes) {
    if (shape.isDragging) {
      shape.x = mouseX - shape.offsetX;
      shape.y = mouseY - shape.offsetY;
    }
  }
}

function mouseReleased() {
  for (let shape of shapes) {
    shape.isDragging = false;
    for (let hole of holes) {
      if (hole.contains(shape)) {
        shape.x = hole.x;
        shape.y = hole.y;
        break;
      }
    }
  }
}

class Shape {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.isDragging = false;
    this.offsetX = 0;
    this.offsetY = 0;
  }
  
  display() {
    if (this.type === 'circle') {
      fill(255, 0, 0);
      ellipse(this.x, this.y, 50);
    } else if (this.type === 'square') {
      fill(0, 255, 0);
      rect(this.x - 25, this.y - 25, 50, 50);
    } else if (this.type === 'triangle') {
      fill(0, 0, 255);
      triangle(this.x, this.y - 25, this.x - 25, this.y + 25, this.x + 25, this.y + 25);
    }
  }
  
  isMouseInside() {
    if (this.type === 'circle') {
      return dist(mouseX, mouseY, this.x, this.y) < 25;
    } else if (this.type === 'square') {
      return mouseX > this.x - 25 && mouseX < this.x + 25 && mouseY > this.y - 25 && mouseY < this.y + 25;
    } else if (this.type === 'triangle') {
      // Check if mouse is inside triangle
      let d1 = this.triangleArea(this.x, this.y - 25, this.x - 25, this.y + 25, this.x + 25, this.y + 25);
      let d2 = this.triangleArea(mouseX, mouseY, this.x - 25, this.y + 25, this.x + 25, this.y + 25);
      let d3 = this.triangleArea(this.x, this.y - 25, mouseX, mouseY, this.x + 25, this.y + 25);
      let d4 = this.triangleArea(this.x, this.y - 25, this.x - 25, this.y + 25, mouseX, mouseY);
      return (d1 === d2 + d3 + d4);
    }
    return false;
  }

  // Function to calculate area of triangle using vertex coordinates
  triangleArea(x1, y1, x2, y2, x3, y3) {
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2);
  }
}

class Hole {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
  }
  
  display() {
    stroke(0);
    noFill();
    if (this.type === 'circle') {
      ellipse(this.x, this.y, 50);
    } else if (this.type === 'square') {
      rect(this.x - 25, this.y - 25, 50, 50);
    } else if (this.type === 'triangle') {
      triangle(this.x, this.y - 25, this.x - 25, this.y + 25, this.x + 25, this.y + 25);
    }
  }
  
  contains(shape) {
    if (this.type === shape.type) {
      return dist(this.x, this.y, shape.x, shape.y) < 25;
    }
    return false;
  }
}

let puzzleImage, bg, rows, columns, w, h, numberCorrect, solved;
numberCorrect = 0;
solved = false;
let pieces = [];
let showInstructions = true;

class Piece {
  constructor(myImage, x, y, w, h, sx, sy) {
    this.myImage = myImage;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.sx = sx;
    this.sy = sy;
    this.drag = false;
    this.tx = 155 + (sx / puzzleImage.width) * 238;
    this.ty = 80 + (sy / puzzleImage.height) * 238;
    this.correct = false;
  }

  show() {
    if (this.drag) {
      fill(0, 100);
      noStroke();
      rect(this.x + 5, this.y + 5, this.w, this.h);
    }
    image(
      this.myImage,
      this.x,
      this.y,
      this.w,
      this.h,
      this.sx,
      this.sy,
      this.w,
      this.h
    );
  }

  clicked(x, y) {
    if (
      x > this.x &&
      x < this.x + this.w &&
      y > this.y &&
      y < this.y + this.h
    ) {
      this.drag = true;
      this.x = x - this.w / 2;
      this.y = y - this.h / 2;
      let myIndexPosition = pieces.indexOf(this);
      pieces.splice(myIndexPosition, 1);
      pieces.push(this);
    }
  }

  active(x, y) {
    cursor("grabbing");
    if (this.drag) {
      this.x = x - this.w / 2;
      this.y = y - this.h / 2;
    }
  }

  check() {
    this.drag = false;
    cursor("grab");
    if (abs(this.x - this.tx) < 10 && abs(this.y - this.ty) < 10) {
      this.correct = true;
      this.x = this.tx;
      this.y = this.ty;
    } else {
      this.correct = false;
    }
  }
}

function setup() {
  rows = 3;
  columns = 3;
  w = 300 / columns;
  h = 300 / rows;
  createCanvas(400, 400);

  let puzzleElement = createImg("images/puzzle-image-copy.png", () => {
    puzzleImage = createImage(puzzleElement.width, puzzleElement.height);
    puzzleImage.drawingContext.drawImage(puzzleElement.elt, 0, 0);

    let i = 0;
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < columns; x++) {
        pieces[i] = new Piece(puzzleImage, 0, 0, w, h, x * w, y * h);
        i++;
      }
    }

    for (let i = 0; i < pieces.length; i++) {
      pieces[i].x = random(0, width - w);
      pieces[i].y = random(0, height - h);
    }
  });
  puzzleElement.hide();

  let bgElement = createImg("images/bg.png", () => {
    bg = createImage(bgElement.width, bgElement.height);
    bg.drawingContext.drawImage(bgElement.elt, 0, 0);
  });
  bgElement.hide();
}

function draw() {
  if (bg) {
    background(bg);
  } else {
    background(220);
  }

  noFill();
  stroke(0);
  strokeWeight(2);
  rect(155, 80, 238, 238);

  fill(255);
  noStroke();
  textSize(32);
  text(numberCorrect, width - 50, height - 35);

  for (let i = 0; i < pieces.length; i++) {
    if (solved) {
      pieces[i].x += random(-2, 2);
      pieces[i].y += random(-2, 2);
    }
    pieces[i].show();
  }

  if (showInstructions) {
    drawInstructionsWindow();
  }
}

function drawInstructionsWindow() {
  const winWidth = 200; // Window width
  const winHeight = 150; // Window height
  const winX = (width - winWidth) / 2; // Centering the window horizontally
  const winY = (height - winHeight) / 2; // Centering the window vertically

  fill(255);
  stroke(0);
  strokeWeight(2);
  rect(winX, winY, winWidth, winHeight, 5); // Draw the window with a larger size

  fill(0);
  noStroke();
  textSize(12);
  textAlign(LEFT, TOP);
  text("Instructions:\n- Drag pieces to the grid\n- Align them correctly", winX + 10, winY + 10);

  fill(255, 0, 0);
  noStroke();
  rect(winX + winWidth - 20, winY + 5, 15, 15, 2); // Move the red background up slightly

  fill(255);
  textSize(8);
  textAlign(CENTER, CENTER);
  text("X", winX + winWidth - 12, winY + 12); // Draw "X" in the close button
}


function mousePressed() {
  if (showInstructions) {
    const winWidth = 200;
    const winHeight = 150;
    const winX = (width - winWidth) / 2;
    const winY = (height - winHeight) / 2;

    if (
      mouseX > winX + winWidth - 20 && mouseX < winX + winWidth - 5 &&
      mouseY > winY + 10 && mouseY < winY + 25
    ) {
      showInstructions = false; // Close the instruction window when clicking the "X"
      return;
    }
  }

  for (let i = 0; i < pieces.length; i++) {
    pieces[i].clicked(mouseX, mouseY);
  }
}

function mouseDragged() {
  for (let i = 0; i < pieces.length; i++) {
    pieces[i].active(mouseX, mouseY);
  }
}

function mouseReleased() {
  numberCorrect = 0;
  for (let i = 0; i < pieces.length; i++) {
    pieces[i].check();
    if (pieces[i].correct == true) {
      numberCorrect++;
    }
  }
  if (numberCorrect == pieces.length) {
    solved = true;
  }
}

let currentColor = 'black';
let shapePoints = [];
let tracedPoints = [];
let completed = false;
let shapePerimeter = 0;

function setup() {
  createCanvas(400, 400);
  
  // Define shape points for tracing (a star shape)
  shapePoints = [
    createVector(150, 20),
    createVector(215, 220),
    createVector(50, 100),
    createVector(250, 100),
    createVector(85, 220)
  ];
  
  // Calculate the shape perimeter
  shapePerimeter = calculatePerimeter(shapePoints);
  
  // Create color choices
  const colors = ['red', 'green', 'blue', 'yellow', 'purple'];
  let xPos = 300;
  let yPos = 50;
  
  for (let color of colors) {
    let colorDiv = createDiv('');
    colorDiv.style('background-color', color);
    colorDiv.style('width', '50px');
    colorDiv.style('height', '30px');
    colorDiv.style('margin', '5px');
    colorDiv.mousePressed(() => chooseColor(color));
    colorDiv.position(xPos, yPos);
    yPos += 35; // Stack the color boxes
  }
}

function draw() {
  background(220);
  
  // Draw the shape to be traced
  stroke(0);
  fill(255);
  beginShape();
  for (let pt of shapePoints) {
    vertex(pt.x, pt.y);
  }
  endShape(CLOSE);
  
  // Draw traced points
  if (tracedPoints.length > 0) {
    stroke(currentColor);
    strokeWeight(2);
    beginShape();
    for (let pt of tracedPoints) {
      vertex(pt.x, pt.y);
    }
    endShape();
  }
  
  // Display completion message
  if (completed) {
    fill(0);
    textSize(32);
    textAlign(CENTER);
    text("Yay!", width / 2, height / 2);
  }
}

function mousePressed() {
  if (!completed && isInsideShape(mouseX, mouseY)) {
    tracedPoints = []; // Clear previous traces
    addPoint(mouseX, mouseY);
  }
}

function mouseDragged() {
  if (!completed && isInsideShape(mouseX, mouseY)) {
    addPoint(mouseX, mouseY);
  }
}

function mouseReleased() {
  if (tracedPoints.length > 0) {
    // Check if 70% or more of the shape is traced
    let tracedLength = calculateTracedLength(tracedPoints);
    if (tracedLength >= 0.7 * shapePerimeter) {
      completed = true; // Mark as completed
    }
  }
}

function chooseColor(color) {
  currentColor = color; // Set the current color to the chosen color
}

function addPoint(x, y) {
  tracedPoints.push(createVector(x, y)); // Add the current point to traced points
}

function isInsideShape(x, y) {
  let inside = false;
  beginShape();
  for (let pt of shapePoints) {
    vertex(pt.x, pt.y);
  }
  endShape(CLOSE);
  
  // Use ray-casting algorithm to determine if the point is inside the shape
  for (let i = 0; i < shapePoints.length; i++) {
    let j = (i + 1) % shapePoints.length;
    if ((shapePoints[i].y > y) != (shapePoints[j].y > y) &&
        (x < (shapePoints[j].x - shapePoints[i].x) * (y - shapePoints[i].y) / (shapePoints[j].y - shapePoints[i].y) + shapePoints[i].x)) {
      inside = !inside;
    }
  }
  return inside;
}

// Function to calculate the perimeter of the shape
function calculatePerimeter(points) {
  let perimeter = 0;
  for (let i = 0; i < points.length; i++) {
    let nextIndex = (i + 1) % points.length;
    perimeter += dist(points[i].x, points[i].y, points[nextIndex].x, points[nextIndex].y);
  }
  return perimeter;
}

// Function to calculate the length of the traced path
function calculateTracedLength(points) {
  let length = 0;
  for (let i = 0; i < points.length - 1; i++) {
    length += dist(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
  }
  return length;
}

/*shapePoints = [
    createVector(150, 20),
    createVector(200, 200),
    createVector(50, 100),
    createVector(250, 100),
    createVector(75, 200)
  ];*/
